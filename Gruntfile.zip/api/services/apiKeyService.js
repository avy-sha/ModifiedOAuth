/**
 * Created by abhinav on 8/23/17.
 */

module.exports = {
  //more details will be added i.e email scope etc
  encryptApiKey:function(email,scope){
  var key ;
  //TODO: remove the next line
  var testkey = "sdvehgfjhf786e73269jdcbuh79wet7fvyefyv";
  key=testkey;
    return key;
  },
  decryptApiKey:function(key){
    var data={};
    return data;
  }
};

